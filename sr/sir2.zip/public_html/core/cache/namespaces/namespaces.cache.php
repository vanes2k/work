<?php  return array (
  'core' => 
  array (
    'name' => 'core',
    'path' => '/home/n/nikidem/sirchaplin.ru/public_html/manager/',
    'assets_path' => '/home/n/nikidem/sirchaplin.ru/public_html/manager/assets/',
  ),
  'migx' => 
  array (
    'name' => 'migx',
    'path' => '/home/n/nikidem/sirchaplin.ru/public_html/core/components/migx/',
    'assets_path' => '/home/n/nikidem/sirchaplin.ru/public_html/assets/components/migx/',
  ),
  'pdotools' => 
  array (
    'name' => 'pdotools',
    'path' => '/home/n/nikidem/sirchaplin.ru/public_html/core/components/pdotools/',
    'assets_path' => '',
  ),
  'simpleacecodeeditor' => 
  array (
    'name' => 'simpleacecodeeditor',
    'path' => '/home/n/nikidem/sirchaplin.ru/public_html/core/components/simpleacecodeeditor/',
    'assets_path' => '',
  ),
  'tinymcerte' => 
  array (
    'name' => 'tinymcerte',
    'path' => '/home/n/nikidem/sirchaplin.ru/public_html/core/components/tinymcerte/',
    'assets_path' => '/home/n/nikidem/sirchaplin.ru/public_html/assets/components/tinymcerte/',
  ),
);