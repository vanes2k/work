<?php
return array (
  0 => '/root',
  1 => '/root/n_type_template',
  2 => '/root/n_type_chunk',
  3 => '/root/n_type_snippet',
  4 => '/root/n_type_tv',
);
