<?php
return 'modx-resource-template';
