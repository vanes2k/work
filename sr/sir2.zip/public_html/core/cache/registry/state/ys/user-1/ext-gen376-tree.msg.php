<?php
return '/Filesystem/tpl/img/banner';
