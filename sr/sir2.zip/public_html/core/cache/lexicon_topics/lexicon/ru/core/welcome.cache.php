<?php  return array (
  'modx_news' => 'Новости MODX',
  'security_notices' => 'Безопасность',
  'welcome_messages' => 'Всего сообщений в вашем почтовом ящике: <strong>%d</strong>, из них не прочитано <strong>%s</strong>.',
  'welcome_title' => 'Добро пожаловать в систему управления контентом MODX',
  'yourinfo_message' => 'Этот раздел показывает информацию о вас:',
  'yourinfo_previous_login' => 'Ваш последний вход:',
  'yourinfo_title' => 'Информация о вас',
  'yourinfo_total_logins' => 'Общее количество входов:',
  'yourinfo_username' => 'Вы вошли как:',
);