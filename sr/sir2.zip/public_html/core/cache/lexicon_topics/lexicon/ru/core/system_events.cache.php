<?php  return array (
  'clear' => 'Очистить',
  'error_log' => 'Журнал ошибок',
  'error_log_desc' => 'Здесь находится журнал ошибок MODX Revolution:',
  'error_log_download' => 'Скачать журнал ошибок ([[+size]])',
  'error_log_too_large' => 'Журнал ошибок <em>[[+name]]</em> слишком большой для просмотра. Вы можете скачать журнал, нажав на кнопку ниже.',
  'system_events' => 'Системные события',
  'priority' => 'Приоритет',
);