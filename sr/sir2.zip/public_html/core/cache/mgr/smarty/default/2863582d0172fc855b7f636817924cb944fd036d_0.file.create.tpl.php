<?php
/* Smarty version 3.1.33, created on 2020-08-07 12:30:57
  from '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/chunk/create.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5f2d1f5185f381_37328051',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2863582d0172fc855b7f636817924cb944fd036d' => 
    array (
      0 => '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/chunk/create.tpl',
      1 => 1596791199,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d1f5185f381_37328051 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-chunk-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onChunkFormPrerender']->value;
}
}
