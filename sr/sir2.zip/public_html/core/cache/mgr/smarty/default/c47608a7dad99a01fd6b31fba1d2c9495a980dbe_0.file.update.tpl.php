<?php
/* Smarty version 3.1.33, created on 2020-08-07 12:30:17
  from '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/template/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5f2d1f292c8a86_65613917',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c47608a7dad99a01fd6b31fba1d2c9495a980dbe' => 
    array (
      0 => '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/template/update.tpl',
      1 => 1596791199,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d1f292c8a86_65613917 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-template-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onTempFormPrerender']->value;
}
}
