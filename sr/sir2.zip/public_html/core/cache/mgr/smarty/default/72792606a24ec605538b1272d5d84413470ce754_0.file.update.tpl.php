<?php
/* Smarty version 3.1.33, created on 2020-08-07 14:30:57
  from '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/tv/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5f2d3b71205fe0_57147595',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '72792606a24ec605538b1272d5d84413470ce754' => 
    array (
      0 => '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/tv/update.tpl',
      1 => 1596791200,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d3b71205fe0_57147595 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-tv-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onTVFormPrerender']->value;
}
}
