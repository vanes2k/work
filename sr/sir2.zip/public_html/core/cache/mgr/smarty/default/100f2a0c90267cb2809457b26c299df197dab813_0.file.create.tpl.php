<?php
/* Smarty version 3.1.33, created on 2020-08-07 14:30:25
  from '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/tv/create.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5f2d3b516b2806_00898281',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '100f2a0c90267cb2809457b26c299df197dab813' => 
    array (
      0 => '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/tv/create.tpl',
      1 => 1596791200,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d3b516b2806_00898281 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-tv-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onTVFormPrerender']->value;
}
}
