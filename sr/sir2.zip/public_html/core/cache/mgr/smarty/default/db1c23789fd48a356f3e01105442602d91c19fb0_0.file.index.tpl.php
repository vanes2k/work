<?php
/* Smarty version 3.1.33, created on 2020-08-07 12:20:02
  from '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/workspaces/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5f2d1cc2e808a8_80064640',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'db1c23789fd48a356f3e01105442602d91c19fb0' => 
    array (
      0 => '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/workspaces/index.tpl',
      1 => 1596791168,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d1cc2e808a8_80064640 (Smarty_Internal_Template $_smarty_tpl) {
echo (($tmp = @$_smarty_tpl->tpl_vars['error']->value)===null||$tmp==='' ? '' : $tmp);?>

<div id="modx-panel-workspace-div"></div>
<?php }
}
