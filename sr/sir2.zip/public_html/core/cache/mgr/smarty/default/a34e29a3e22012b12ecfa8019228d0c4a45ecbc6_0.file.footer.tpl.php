<?php
/* Smarty version 3.1.33, created on 2020-08-07 12:16:26
  from '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5f2d1bea6c5031_53698608',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a34e29a3e22012b12ecfa8019228d0c4a45ecbc6' => 
    array (
      0 => '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/footer.tpl',
      1 => 1596791144,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d1bea6c5031_53698608 (Smarty_Internal_Template $_smarty_tpl) {
?>    </div>
    <!-- #modx-content-->
    <div id="modx-footer"></div>
</div>
<!-- #modx-container -->

</body>
</html><?php }
}
