<?php
/* Smarty version 3.1.33, created on 2020-08-07 12:50:07
  from '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/snippet/update.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5f2d23cf8e4c38_79645344',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e15389f4d3bee49a22c465fff190ba7dc11d0a45' => 
    array (
      0 => '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/snippet/update.tpl',
      1 => 1596791199,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d23cf8e4c38_79645344 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="modx-panel-snippet-div"></div>
<?php echo $_smarty_tpl->tpl_vars['onSnipFormPrerender']->value;
}
}
