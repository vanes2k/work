<?php
/* Smarty version 3.1.33, created on 2020-08-07 14:30:26
  from '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/tv/renders/properties/default.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5f2d3b529b6229_79800366',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '89e7846ea996257d4fa592f9796de2250df2e7f8' => 
    array (
      0 => '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/element/tv/renders/properties/default.tpl',
      1 => 1596791279,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d3b529b6229_79800366 (Smarty_Internal_Template $_smarty_tpl) {
?>&nbsp;<?php }
}
