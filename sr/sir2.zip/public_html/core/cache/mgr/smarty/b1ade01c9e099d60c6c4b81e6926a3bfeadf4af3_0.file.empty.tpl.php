<?php
/* Smarty version 3.1.33, created on 2020-08-07 14:30:26
  from '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/empty.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5f2d3b523db4e3_82512037',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b1ade01c9e099d60c6c4b81e6926a3bfeadf4af3' => 
    array (
      0 => '/home/n/nikidem/sirchaplin.ru/public_html/manager/templates/default/empty.tpl',
      1 => 1596791144,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d3b523db4e3_82512037 (Smarty_Internal_Template $_smarty_tpl) {
?> <?php }
}
