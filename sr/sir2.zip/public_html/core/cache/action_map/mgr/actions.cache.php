<?php  return array (
  1 => 
  array (
    'id' => '1',
    'namespace' => 'migx',
    'controller' => 'index',
    'haslayout' => '0',
    'lang_topics' => 'example:default',
    'assets' => '',
    'help_url' => '',
    'namespace_name' => 'migx',
    'namespace_path' => '/home/n/nikidem/sirchaplin.ru/public_html/core/components/migx/',
    'namespace_assets_path' => '{assets_path}components/migx/',
  ),
);