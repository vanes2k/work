<?php if(time() > 1607012988){return null;} return array (
  'http://www.sirchaplin.ru/' => '<url>
	<loc>http://www.sirchaplin.ru/</loc>
	<lastmod>2020-08-07T14:32:07+03:00</lastmod>
	<changefreq>monthly</changefreq>
	<priority>0.25</priority>
</url>',
  'http://www.sirchaplin.ru/robots.txt' => '<url>
	<loc>http://www.sirchaplin.ru/robots.txt</loc>
	<lastmod>2020-08-10T12:35:49+03:00</lastmod>
	<changefreq>monthly</changefreq>
	<priority>0.25</priority>
</url>',
);